dummy4 policy

https://voicevox.hiroshiba.jp/
