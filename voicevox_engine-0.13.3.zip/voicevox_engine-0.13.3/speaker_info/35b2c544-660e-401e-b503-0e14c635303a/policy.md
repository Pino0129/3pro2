dummy3 policy

https://voicevox.hiroshiba.jp/
